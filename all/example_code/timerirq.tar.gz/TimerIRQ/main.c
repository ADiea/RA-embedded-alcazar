#include "stm32f05xxx.h"

void ToggleBlueLED();
int Count = 0;

// Interrupt service routines are the same as normal
// subroutines (or C funtions) in Cortex-M micros.
// The following should happen at a rate of 1kHz.
// The following function is associated with the TIM1 interrupt 
// via the interrupt vector table defined in cstartup_M.c 
void Timer1ISR() 
{
  TIM1_SR &= ~BIT0; // clear update interrupt flag
  Count++;
  if (Count > 1000) { // toggle the state of the LED every second
    Count = 0;
    ToggleBlueLED();
  }   
}

void delay(int dly)
{
  while( dly--);
}

void SysInit()
{
  // Set up output port bit for LED
  RCC_AHBENR |= BIT19; // turn on clock for PORTC
  GPIOC_MODER |= BIT16; // Make bit 8 an output  
  // Set up timer
  RCC_APB2ENR |= BIT11; // turn on clock for timer1
  TIM1_ARR = 8000; // reload counter with 8000 at each overflow (equiv to 1ms)
  ISER |= BIT13; // enable timer interrupts in the NVIC
  TIM1_CR1 |= BIT4; // Downcounting    
  TIM1_CR1 |= BIT0; // enable counting    
  TIM1_DIER  |= BIT0; // enable update event (reload event) interrupt  
  enable_interrupts();

}
void ToggleBlueLED() 
{    
  GPIOC_ODR ^= BIT8;
}
int main()
{
  SysInit();
  while(1) {    
    delay(10);    
  }
  return 0;
}
