// servo.h
void initServos();
void setAngle(int motor, int Angle);
