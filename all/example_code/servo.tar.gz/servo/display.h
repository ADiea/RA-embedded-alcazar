// display.h
// HD44780 compatible display wired as follows:
// PB4,5,6,7 wired to DB4,5,6,7 (4 bit interface)
// PB15 wired to E
// PB14 wired to R/W
// PB13 wired to RS

#define CLEAR_BIT(addr,mask) (addr &= ~(mask))
#define SET_BIT(addr,mask) (addr |= (mask))


#define		DISP_ON			0x0c	        //LCD control constants
#define		DISP_OFF		0x08	        //
#define		CLR_DISP		0x01    	//
#define		CUR_HOME		0x02	        //

void putc(char c);
void puts(char *str);
void initdisplay();
void printbyte(unsigned int theByte);
void printhex(unsigned int Number);
void printshort(short Number);