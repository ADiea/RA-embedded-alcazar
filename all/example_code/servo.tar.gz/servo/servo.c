// servo.c
// Simple servo motor control demo
// This controls two servo motors.  The servo control signal consists of a PWM signal the duty of which
// controls servo angle.  PWM frequency is around 30Hz.
// PWM will be generated using Timer 2.
// One motor is controlled using the PB10 output pin (TIM2_CH3), the other by PB11 pin (TIM2_CH4)
#include "stm32f05xxx.h"
#include "servo.h"
void initServos()
{
	// Make sure GPIOB is enabled 
	RCC_AHBENR |= BIT18;
	// Configure PB10 and PB11 for alternate function (both are set to AF2)
	GPIOB_MODER &= ~(BIT22 | BIT20);	// configure for alternate function
	GPIOB_MODER |= (BIT23 | BIT21);
	GPIOB_AFRH &= (BIT15 | BIT14 | BIT12 | BIT11 | BIT10 | BIT8);
	GPIOB_AFRH |= (BIT13 | BIT9); // select AF2
	// Turn on Timer 2
	RCC_APB1ENR |= BIT0;
	// Set PWM period
	TIM2_ARR = 20000;
	TIM2_PSC = 8;
	// Enable output compare (PWM) on channels 3 and 4
	TIM2_CR1 = BIT7;

	TIM2_CCER = 0;
	TIM2_CCMR2 |= (BIT14 | BIT13 | BIT6 | BIT5 | BIT11 | BIT3 );
	TIM2_CCMR2 &= ~( BIT4 | BIT12 );
	
	// Set initial duty of both channels to 0
	TIM2_CCR3 = 360;
	TIM2_CCR4 = 360;
	// Enable counting
	TIM2_EGR |= (BIT0);
	TIM2_SR = 0;
	TIM2_CCER = (BIT12 | BIT8);
	TIM2_CR1 |= 1;
}
void setAngle(int motor, int Angle) 
{
	if (motor==0)
		TIM2_CCR3 = Angle ;
	if (motor==1)
		TIM2_CCR4 = Angle ;
	
}
