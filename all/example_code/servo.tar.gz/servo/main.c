#include "stm32f05xxx.h"
#include "display.h"
#include "keypad.h"

void delay(int dly)
{
  while (dly--);
}

int main()
{
	int Angle1;
	int Angle2;
	char key;
  initdisplay();
  cleardisplay();
  puts("1234567890ABCDEF");
  delay(1000000);
	initkeys();
	initServos();  
	Angle1 = Angle2 =1000;
	while(1) 
  {
		cleardisplay();	
		key=scankeys();
		if (key=='1')
			Angle1++;
		if (key=='2')
			Angle1--;
		if (Angle1 < 0)
			Angle1 = 0;
		printshort(Angle1);
		putc(' ');
		setAngle(0,Angle1);
		if (key=='4')
			Angle2++;
		if (key=='5')
			Angle2--;
		if (Angle2 < 0)
			Angle2 = 0;
		printshort(Angle2);

		setAngle(1,Angle2);	
		delay(10000);
	}    
}
