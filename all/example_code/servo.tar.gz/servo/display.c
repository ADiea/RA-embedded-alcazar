// Display library for interfacing an STM32F0Discovery board to 
// an HD44780 compatible display
// Writte by Frank Duignan
#include "stm32f05xxx.h"
#include "display.h"
int CursorLocation;
void delay100u(int dly)
{
  // delays for 100 microseconds * dly
  // at default clock speed (16MHz)
  int inner;
  while(dly--) 
  {
    inner=52;
    while(inner--);
  }
}
void cycle_e()
{
  SET_BIT(GPIOB_ODR,BIT15);
  delay100u(1);
  CLEAR_BIT(GPIOB_ODR,BIT15);
  delay100u(1);
}
void putc(char c)
{
  CursorLocation++;
  if (CursorLocation > 16)
    cleardisplay();
  if (CursorLocation == 9)
    putcmd(0xc0);
  GPIOB_ODR &= 0x0f; // clear upper 4 bits
  GPIOB_ODR |= (c & 0xf0); // set appropriate upper 4 bits
  SET_BIT(GPIOB_ODR,BIT13); // select data register
  cycle_e();
  GPIOB_ODR &= 0x0f; // clear upper 4 bits
  GPIOB_ODR |= ((c << 4) & 0xf0); // set appropriate upper 4 bits
  SET_BIT(GPIOB_ODR,BIT13); // select data register
  cycle_e();
}
void putcmd(char c)
{
  GPIOB_ODR &= 0x0f; // clear upper 4 bits
  GPIOB_ODR |= (c & 0xf0); // set appropriate upper 4 bits
  CLEAR_BIT(GPIOB_ODR,BIT13); // select command register
  cycle_e();
  GPIOB_ODR &= 0x0f; // clear upper 4 bits
  GPIOB_ODR |= ((c << 4) & 0xf0); // set appropriate upper 4 bits
  CLEAR_BIT(GPIOB_ODR,BIT13); // select command register
  cycle_e();
}
void puts(char *str)
{
  while(*str)
    putc(*str++);
}
void initdisplay()
{
  // configure GPIOB bits
  RCC_AHBENR |= BIT18; // turn on clock for GPIOB
  SET_BIT(GPIOB_MODER,(BIT30 | BIT28 | BIT26 | BIT14 | BIT12 | BIT10 | BIT8)); 
  CLEAR_BIT(GPIOB_MODER,(BIT31 | BIT29 | BIT27 | BIT15 | BIT13 | BIT11 | BIT9)); 
  // do software reset of display
  CLEAR_BIT(GPIOB_ODR,BIT13);
  delay100u(1000); // wait for 100ms
  SET_BIT(GPIOB_ODR,(BIT4 | BIT5));
  CLEAR_BIT(GPIOB_ODR, (BIT6 | BIT7) );
  cycle_e(); 
  delay100u(100);                   //10ms
  cycle_e(); 
  delay100u(100);                   //10ms
  cycle_e(); 
  delay100u(100);                   //10ms
  CLEAR_BIT(GPIOB_ODR,BIT4);
  cycle_e();
  putcmd(DISP_ON);
  cleardisplay();
  delay100u(2000); 
}
void cleardisplay() {
    putcmd(CLR_DISP);
    delay100u(20);
    CursorLocation = 0;
}

char HexDigit(int digitvalue) {
  if (digitvalue < 10)
    return(digitvalue + '0');
  else
    return(digitvalue + 'A' - 10);
}
void printbyte(unsigned int theByte) {
  char HexBuffer[3];
  HexBuffer[2] = 0;
  HexBuffer[1] = HexDigit(theByte & 0x000f);
  theByte = theByte >> 4;
  HexBuffer[0] = HexDigit(theByte & 0x000f);
  puts(HexBuffer);
}
void printhex(unsigned int Number) {
  char HexBuffer[9];
  HexBuffer[8] = 0;
  HexBuffer[7] = HexDigit(Number & 0x000f);
  Number = Number >> 4;
  HexBuffer[6] = HexDigit(Number & 0x000f);
  Number = Number >> 4;
  HexBuffer[5] = HexDigit(Number & 0x000f);
  Number = Number >> 4;
  HexBuffer[4] = HexDigit(Number & 0x000f);
	Number = Number >> 4;
  HexBuffer[3] = HexDigit(Number & 0x000f);
  Number = Number >> 4;
  HexBuffer[2] = HexDigit(Number & 0x000f);
  Number = Number >> 4;
  HexBuffer[1] = HexDigit(Number & 0x000f);
  Number = Number >> 4;
  HexBuffer[0] = HexDigit(Number & 0x000f);

  puts(HexBuffer);
}
void printshort(short Number) {
  // need to move to long int to account for
  // negative 32768
  char DecimalBuffer[7];
  long lNumber = Number;
  DecimalBuffer[6] = 0;
  if (lNumber < 0) {
    DecimalBuffer[0] = '-';
    lNumber = -lNumber;
  } else
    DecimalBuffer[0] = '+';
  DecimalBuffer[5] = (lNumber % 10)+'0';
  lNumber = lNumber / 10;
  DecimalBuffer[4] = (lNumber % 10)+'0';
  lNumber = lNumber / 10;
  DecimalBuffer[3] = (lNumber % 10)+'0';
  lNumber = lNumber / 10;
  DecimalBuffer[2] = (lNumber % 10)+'0';
  lNumber = lNumber / 10;
  DecimalBuffer[1] = (lNumber % 10)+'0';
  puts(DecimalBuffer);
}
