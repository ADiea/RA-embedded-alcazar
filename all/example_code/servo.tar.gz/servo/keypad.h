//keypad.h
void initkeys();
char scankeys();
char getc();
