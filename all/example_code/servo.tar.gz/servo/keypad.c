// keypad library for interfacing with a matrix keypad.
/* The keypad is laid out as follows:


		  |(1)  |(2)  |(3)	
		----------------------Row 1
      |(4)  |(5)  |(6)
		----------------------Row 2
      |(7)  |(8)  |(9)
		----------------------Row 3
	    |(*)  |(0)  |(#)
		----------------------Row 4
	    |     |     |
		Col1   Col2   Col3
	

The keypad is connected as follows: 
   PA11 : Column 2
	 PA10 : Row 1
	 PA9  : Column 1
	 PA8  : Row 4
	 PC9  : Column 3
	 PC8	: Row 3
	 PC7 	: Row 2
The control procedure is as follows:
	Make all port bits inputs with pull up resistors
	To scan a row, make the particular port bit an output at logic 0
	If a zero is seen on any of the columns then can conclude that a particular button was pressed
	
*/
#include "stm32f05xxx.h"

#define COLUMN1_TEST ((GPIOA_IDR & BIT9 )==0)
#define COLUMN2_TEST ((GPIOA_IDR & BIT11)==0)
#define COLUMN3_TEST ((GPIOC_IDR & BIT9 )==0)
#define ROW1_ACTIVATE	  GPIOA_MODER |= BIT20
#define ROW1_DEACTIVATE GPIOA_MODER &= ~BIT20
#define ROW2_ACTIVATE	  GPIOC_MODER |= BIT14
#define ROW2_DEACTIVATE GPIOC_MODER &= ~BIT14
#define ROW3_ACTIVATE 	GPIOC_MODER |= BIT16
#define ROW3_DEACTIVATE GPIOC_MODER &= ~BIT16
#define ROW4_ACTIVATE   GPIOA_MODER |= BIT16
#define ROW4_DEACTIVATE GPIOA_MODER &= ~BIT16


void keydelay()
{ // need to allow the weak pull-up resistors
	// drag the port pins back up
	int i=10;
	while(i--);	
}
void initkeys();
char scankeys();

void initkeys()
{
	// Make sure GPIOC and GPIOA are turned on
	RCC_AHBENR |= (BIT19 | BIT17);
	// Configure pins as inputs
	GPIOA_MODER &= ~(BIT23 | BIT22 | \
									 BIT21 | BIT20 | \
									 BIT19 | BIT18 | \
									 BIT17 | BIT16);

	GPIOC_MODER &= ~(BIT19 | BIT18 | BIT17 | BIT16 | BIT15 | BIT14);
	// Enable pull-up resistors on port pins
	GPIOA_PUPDR &= ~(BIT23 | \
									 BIT21 | \
									 BIT19 | \
									 BIT17 );
	GPIOA_PUPDR |=   ( BIT22 | \
									   BIT20 | \
									 	 BIT18 | \
									   BIT16);
	GPIOC_PUPDR &= ~(BIT19 | BIT17 | BIT15 );
	GPIOC_PUPDR |= (BIT18 | BIT16 | BIT14 );
	// Write zero to output data register bits
	GPIOA_ODR &= ~(BIT11 | BIT10 | BIT9 | BIT8);
	GPIOC_ODR &= ~(BIT9 | BIT8 | BIT7);
}
char scankeys()
{
	ROW1_DEACTIVATE;
	ROW2_DEACTIVATE;
	ROW3_DEACTIVATE;
	ROW4_DEACTIVATE;

	ROW1_ACTIVATE;
	if ( COLUMN1_TEST )	
		return '1';
	if ( COLUMN2_TEST )
		return '2';
	if ( COLUMN3_TEST )	
		return '3';
	ROW1_DEACTIVATE;
	keydelay();

	ROW2_ACTIVATE;
	if ( COLUMN1_TEST )
		return '4';
	if ( COLUMN2_TEST )
		return '5';
	if ( COLUMN3_TEST )
		return '6';
	ROW2_DEACTIVATE;
	keydelay();

	ROW3_ACTIVATE;
	if ( COLUMN1_TEST )
		return '7';
	if ( COLUMN2_TEST )
		return '8';
	if ( COLUMN3_TEST )
		return '9';
	ROW3_DEACTIVATE;
	keydelay();

	ROW4_ACTIVATE;
	if ( COLUMN1_TEST ) 
		return '*';
	if ( COLUMN2_TEST )
		return '0';
	if ( COLUMN3_TEST )
		return '#';
	ROW4_DEACTIVATE;
	keydelay();
	return 0;
}
char getc()
{
	int timeout;
	char ch=0;
	while(!ch)
	{
		ch = scankeys();
	}
	timeout=1000;
	while((scankeys()) && (timeout--)); // wait for key release	with timeout
	return ch;
}
